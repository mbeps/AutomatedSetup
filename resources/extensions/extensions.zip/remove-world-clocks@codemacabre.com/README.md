# Remove World Clocks GNOME Extension

This is a simple GNOME extension to remove the world clocks section from the date menu.

Install this extension directly from https://extensions.gnome.org/extension/6973/remove-world-clocks/

To manually install this extension, copy the `remove-world-clocks@codemacabre.com` folder to `~/.local/share/gnome-shell/extensions`.
