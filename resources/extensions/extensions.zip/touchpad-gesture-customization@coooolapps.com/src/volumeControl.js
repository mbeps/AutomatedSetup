import Clutter from 'gi://Clutter';
import Shell from 'gi://Shell';
import { ExtSettings } from '../constants.js';
import { createSwipeTracker } from './swipeTracker.js';
import { getVirtualKeyboard } from './utils/keyboard.js';

var VolumeGestureState;

(function (VolumeGestureState) {
    VolumeGestureState[VolumeGestureState["VOLUME_UP"] = 1] = "VOLUME_UP";
    VolumeGestureState[VolumeGestureState["DEFAULT"] = 0] = "DEFAULT";
    VolumeGestureState[VolumeGestureState["VOLUME_DOWN"] = -1] = "VOLUME_DOWN";
})(VolumeGestureState || (VolumeGestureState = {}));

export class VolumeControlGestureExtension {

    constructor() {
        this._volumeGestureState = VolumeGestureState.DEFAULT;
        this._progress = 0;
        this._keyboard = getVirtualKeyboard();
        this._swipeTracker = createSwipeTracker(global.stage, ExtSettings.DEFAULT_OVERVIEW_GESTURE ? [4] : [3], Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW, Clutter.Orientation.VERTICAL, true, 1, { allowTouch: false });
        this._connectHandlers = [
            this._swipeTracker.connect('begin', this._gestureBegin.bind(this)),
            this._swipeTracker.connect('update', this._gestureUpdate.bind(this)),
            this._swipeTracker.connect('end', this._gestureEnd.bind(this)),
        ];
        this._progress = 0;
    }

    destroy() {
        this._connectHandlers.forEach(handle => this._swipeTracker.disconnect(handle));
        this._connectHandlers = [];
        this._swipeTracker.destroy();
    }

    _gestureBegin(_tracker) {
        this._volumeGestureState = VolumeGestureState.DEFAULT;
        _tracker.confirmSwipe(global.screen_height, [
            VolumeGestureState.VOLUME_DOWN,
            VolumeGestureState.DEFAULT,
            VolumeGestureState.VOLUME_UP,
        ], VolumeGestureState.DEFAULT, VolumeGestureState.DEFAULT);
    }

    _gestureUpdate(_tracker, progress) {
        this._progress = Math.clamp(progress, VolumeGestureState.VOLUME_DOWN, VolumeGestureState.VOLUME_UP);

        switch (this._volumeGestureState) {
            case VolumeGestureState.DEFAULT:
                if (this._progress > VolumeGestureState.DEFAULT) {
                    this._volumeGestureState = VolumeGestureState.VOLUME_UP;
                }
                else {
                    this._volumeGestureState = VolumeGestureState.VOLUME_DOWN;
                }

                break;
            case VolumeGestureState.VOLUME_UP:
                this._keyboard.sendKeys([Clutter.KEY_AudioRaiseVolume]);
                this._volumeGestureState = VolumeGestureState.DEFAULT;
                break;
            case VolumeGestureState.VOLUME_DOWN:
                this._keyboard.sendKeys([Clutter.KEY_AudioLowerVolume]);
                this._volumeGestureState = VolumeGestureState.DEFAULT;
        }
    }

    _gestureEnd(_tracker, duration, progress) {
        this._volumeGestureState = VolumeGestureState.DEFAULT;
    }

}
