export const UUID = 'draw-on-your-screen2@zhrexl.github.com';
export const CURATED_UUID = UUID.replace(/@/gi, '_at_').replace(/[^a-z0-9+_-]/gi, '_');