
import {domain as gettextDomain} from 'gettext';

const Gettext = gettextDomain('gtk4-ding');
const _ = Gettext.gettext;

export {Gettext, _};
