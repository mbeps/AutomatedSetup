var prefs = (function (glib2, adw1, gtk4) {
    'use strict';

    const ExtensionUtils = imports.misc.extensionUtils;
    const SettingsPath = "org.gnome.shell.extensions.quicksettings-audio-devices-renamer";
    const OutputNamesMap = "output-names-map";
    const InputNamesMap = "input-names-map";
    class SettingsUtils {
        constructor() {
            this.settings = null;
        }
        getSettings() {
            if (!this.settings) {
                this.settings = ExtensionUtils.getSettings(SettingsPath);
            }
            return this.settings;
        }
        getOutputNamesMap() {
            const settings = this.getSettings();
            const value = settings.get_value(OutputNamesMap);
            return value.recursiveUnpack();
        }
        setOutputNamesMap(values) {
            const settings = this.getSettings();
            settings.set_value(OutputNamesMap, new glib2.Variant("a{ss}", values));
        }
        getInputNamesMap() {
            const settings = this.getSettings();
            const value = settings.get_value(InputNamesMap);
            return value.recursiveUnpack();
        }
        setInputNamesMap(values) {
            const settings = this.getSettings();
            settings.set_value(InputNamesMap, new glib2.Variant("a{ss}", values));
        }
        connectToChanges(settingName, func) {
            return this.getSettings().connect(`changed::${settingName}`, func);
        }
        disconnect(subscriptionId) {
            this.getSettings().disconnect(subscriptionId);
        }
        dispose() {
            this.settings = null;
        }
    }

    function validate(namesMap) {
        const customNames = Object.keys(namesMap).reduce((acc, originalName) => {
            return [...acc, namesMap[originalName]];
        }, []);
        if (hasEmptyValues(customNames)) {
            return error("Device name cannot be empty");
        }
        if (hasDuplicates(customNames)) {
            return error("Devices need to have unique names");
        }
        return ok();
    }
    function hasEmptyValues(names) {
        return (names.filter((n) => n === "" || n === null || n === undefined).length > 0);
    }
    function hasDuplicates(names) {
        const set = new Set(names);
        return set.size !== names.length;
    }
    function ok() {
        return {
            isOk: true,
            errorMessage: null,
        };
    }
    function error(message) {
        return {
            isOk: false,
            errorMessage: message,
        };
    }

    function init() { }
    function fillPreferencesWindow(window) {
        const settings = new SettingsUtils();
        window.add(createOutputsPage(settings, window));
        window.add(createInputsPage(settings, window));
    }
    function createOutputsPage(settings, window) {
        const page = new adw1.PreferencesPage({
            title: "Outputs",
            iconName: "audio-speakers-symbolic",
        });
        const group = new adw1.PreferencesGroup({
            title: "Output Audio Devices",
            description: "Rename devices and apply the changes",
        });
        page.add(group);
        const outputs = settings.getOutputNamesMap();
        Object.keys(outputs).forEach((originalName) => {
            const customName = outputs[originalName];
            group.add(createDeviceRow(originalName, customName, settings, "output", window));
        });
        return page;
    }
    function createInputsPage(settings, window) {
        const page = new adw1.PreferencesPage({
            title: "Inputs",
            iconName: "audio-input-microphone-symbolic",
        });
        const group = new adw1.PreferencesGroup({
            title: "Input Audio Devices",
            description: "Rename devices and apply the changes",
        });
        page.add(group);
        const inputs = settings.getInputNamesMap();
        Object.keys(inputs).forEach((originalName) => {
            const customName = inputs[originalName];
            group.add(createDeviceRow(originalName, customName, settings, "input", window));
        });
        return page;
    }
    function createDeviceRow(originalName, customName, settings, type, window) {
        const row = new adw1.EntryRow({
            title: originalName,
            text: customName,
            show_apply_button: true,
        });
        const resetButton = new gtk4.Button({
            icon_name: "view-refresh",
            has_frame: false,
            tooltip_text: "Restore original name",
        });
        resetButton.connect("clicked", () => {
            row.text = originalName;
            restoreDevice(type, settings, originalName);
        });
        row.add_suffix(resetButton);
        row.connect("apply", ({ title, text }) => {
            applyCustomName(type, settings, title, text, window);
        });
        return row;
    }
    function applyCustomName(type, settings, originalName, customName, window) {
        const currentMap = type === "output"
            ? settings.getOutputNamesMap()
            : settings.getInputNamesMap();
        const newMap = {
            ...currentMap,
            [originalName]: customName,
        };
        const validation = validate(newMap);
        if (!validation.isOk) {
            displayError(window, validation.errorMessage);
        }
        else {
            type === "output"
                ? settings.setOutputNamesMap(newMap)
                : settings.setInputNamesMap(newMap);
        }
    }
    function restoreDevice(type, settings, originalName) {
        const currentMap = type === "output"
            ? settings.getOutputNamesMap()
            : settings.getInputNamesMap();
        const newMap = {
            ...currentMap,
            [originalName]: originalName,
        };
        type === "output"
            ? settings.setOutputNamesMap(newMap)
            : settings.setInputNamesMap(newMap);
    }
    function displayError(window, error) {
        window.add_toast(new adw1.Toast({
            title: error,
            priority: adw1.ToastPriority.HIGH,
            timeout: 5,
        }));
    }
    var prefs = { init, fillPreferencesWindow };

    return prefs;

})(imports.gi.GLib, imports.gi.Adw, imports.gi.Gtk);
var init = prefs.init;
var fillPreferencesWindow = prefs.fillPreferencesWindow;
