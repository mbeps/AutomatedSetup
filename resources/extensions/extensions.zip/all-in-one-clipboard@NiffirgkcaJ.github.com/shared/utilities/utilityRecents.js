import GObject from 'gi://GObject';

import { Logger } from './utilityLogger.js';
import { IOFile, IOJson } from './utilityIO.js';

const DEFAULT_MAX_RECENTS_FALLBACK = 45;

/**
 * Shared instances keyed by cache file path to allow multiple consumers to reuse a single manager.
 */
let _instances = null;

/**
 * Returns the shared recents manager registry, creating it on first use.
 *
 * @returns {Map<string, RecentItemsManager>} Recent item managers keyed by cache file path.
 */
function getInstances() {
    if (!_instances) {
        _instances = new Map();
    }
    return _instances;
}

/**
 * Manages a list of recently used items for a specific data type.
 * Handles loading from and saving to a cache file, enforcing a maximum item limit
 * from GSettings, and notifying listeners of changes.
 *
 * @fires recents-changed Emitted when the list of recent items is modified.
 */
export const RecentItemsManager = GObject.registerClass(
    {
        Signals: {
            'recents-changed': {},
        },
    },
    class RecentItemsManager extends GObject.Object {
        /**
         * @param {string} extensionUUID The UUID of the extension.
         * @param {Gio.Settings} settings The GSettings object.
         * @param {string} absolutePath The absolute path for this manager's recents file.
         * @param {string} maxItemsSettingKey The GSettings key for the max items for this type.
         */
        constructor(extensionUUID, settings, absolutePath, maxItemsSettingKey) {
            super();
            this._uuid = extensionUUID;
            this._settings = settings;
            this._refCount = 1;
            this._recents = [];

            if (!absolutePath || typeof absolutePath !== 'string' || absolutePath.trim() === '') {
                throw new Error(`RecentItemsManager requires a valid absolutePath.`);
            }
            this._cacheFilePath = absolutePath.trim();

            if (!maxItemsSettingKey || typeof maxItemsSettingKey !== 'string' || maxItemsSettingKey.trim() === '') {
                throw new Error(`RecentItemsManager requires a valid maxItemsSettingKey for ${this._cacheFilePath}.`);
            }
            this._maxItemsSettingKey = maxItemsSettingKey.trim();

            this._isLoaded = false;
            this._maxItems = this._settings.get_int(this._maxItemsSettingKey);

            this._settingsSignalId = this._settings.connect(`changed::${this._maxItemsSettingKey}`, () => {
                if (!this._settings) return;
                this._maxItems = this._settings.get_int(this._maxItemsSettingKey);
                if (this._isLoaded) {
                    this._pruneRecents();
                    this._save().catch((e) => Logger.warn(`Save after maxItems change failed for ${this._cacheFilePath}: ${e.message}`));
                }
            });

            this._load()
                .then(() => {
                    this._isLoaded = true;
                })
                .catch((e) => {
                    this._isLoaded = true;
                    Logger.warn(`Initial load of recents from ${this._cacheFilePath} failed: ${e.message}. Recents will be empty.`);
                    if (this._settings) {
                        this._recents = [];
                        this.emit('recents-changed');
                    }
                });
        }

        /**
         * Asynchronously loads and parses the recents list from the cache file.
         * @private
         */
        async _load() {
            try {
                if (!this._settings) return;
                const recents = await IOFile.readJson(this._cacheFilePath);
                if (Array.isArray(recents)) {
                    this._recents = recents;
                    this._pruneRecents();
                } else {
                    this._recents = [];
                    if (recents !== null) {
                        Logger.warn(`Recents file ${this._cacheFilePath} content is not an array. Initializing as empty.`);
                    }
                }
            } catch (e) {
                this._recents = [];
                Logger.warn(`Error loading recents from ${this._cacheFilePath}: ${e.message}. Initializing as empty.`);
            } finally {
                if (this._settings) {
                    this.emit('recents-changed');
                }
            }
        }

        /**
         * Asynchronously saves the current recents list to the cache file.
         * @private
         */
        async _save() {
            if (!this._settings) return;
            await IOFile.writeJson(this._cacheFilePath, this._recents);
        }

        /**
         * Adds an item to the top of the recents list.
         * If the item already exists, it is moved to the top.
         * @param {Object} item The item to add that must have a value property.
         */
        addItem(item) {
            if (!this._settings) return;
            if (!item || typeof item.value !== 'string' || item.value.trim() === '') {
                const serialized = IOJson.stringifyText(item);
                Logger.warn(`Attempted to add invalid item to recents for ${this._cacheFilePath}: ${serialized ?? 'null'}`);
                return;
            }
            const existingIndex = this._recents.findIndex((r) => r.value === item.value);
            if (existingIndex > -1) this._recents.splice(existingIndex, 1);

            this._recents.unshift({ ...item });
            this._pruneRecents();
            this._save().catch((e) => Logger.warn(`Save after addItem failed for ${this._cacheFilePath}: ${e.message}`));
            this.emit('recents-changed');
        }

        /**
         * Gets a copy of the current list of recent items.
         * @returns {Array<Object>} The list of recent items.
         */
        getRecents() {
            return [...this._recents];
        }

        /**
         * Trims the recents list to the maximum allowed length.
         * @private
         */
        _pruneRecents() {
            if (!this._settings) return;
            const max = typeof this._maxItems === 'number' && this._maxItems >= 0 ? this._maxItems : DEFAULT_MAX_RECENTS_FALLBACK;
            if (this._recents.length > max) this._recents.length = max;
        }

        /**
         * Cleans up resources such as the GSettings signal connection.
         */
        destroy() {
            this._refCount--;
            if (this._refCount > 0) return;

            getInstances().delete(this._cacheFilePath);

            if (this._settings && this._settingsSignalId > 0) {
                this._settings.disconnect(this._settingsSignalId);
            }

            this._settingsSignalId = 0;
            this._settings = null;
            this._recents = [];
            this._uuid = null;
            this._maxItemsSettingKey = null;
        }

        /**
         * Forces cleanup regardless of the current reference count.
         *
         * @returns {void}
         */
        forceDestroy() {
            this._refCount = 1;
            this.destroy();
        }
    },
);

/**
 * Gets or creates a shared RecentItemsManager instance for the given cache file path.
 * Multiple consumers that manage the same recents file will receive the same instance.
 * Each call increments a reference count and the instance is only destroyed when the last consumer calls destroy.
 *
 * @param {string} extensionUUID The UUID of the extension.
 * @param {Gio.Settings} settings The GSettings object.
 * @param {string} absolutePath The absolute path for this manager's recents file.
 * @param {string} maxItemsSettingKey The GSettings key for the max items for this type.
 * @returns {RecentItemsManager} A shared manager instance.
 */
export function getRecentItemsManager(extensionUUID, settings, absolutePath, maxItemsSettingKey) {
    const key = absolutePath.trim();
    let instance = getInstances().get(key);

    if (instance) {
        instance._refCount++;
        return instance;
    }

    instance = new RecentItemsManager(extensionUUID, settings, absolutePath, maxItemsSettingKey);
    getInstances().set(key, instance);
    return instance;
}

/**
 * Destroys any remaining shared recents managers during extension shutdown.
 *
 * @returns {void}
 */
export function destroyAllRecentItemsManagers() {
    if (!_instances) {
        return;
    }

    const managers = [..._instances.values()];
    _instances.clear();
    managers.forEach((manager) => manager.forceDestroy());
    _instances = null;
}
