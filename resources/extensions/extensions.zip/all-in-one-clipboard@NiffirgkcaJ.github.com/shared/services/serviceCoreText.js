import { Logger } from '../utilities/utilityLogger.js';

/**
 * Core text encoding and decoding service for byte-level integration with files.
 */
export const ServiceCoreText = {
    /**
     * Encodes bytes for storage.
     *
     * @param {Uint8Array} bytes Raw bytes.
     * @returns {Uint8Array} Encoded bytes.
     */
    encode(bytes) {
        return this._encrypt(bytes);
    },

    /**
     * Decodes bytes from storage.
     *
     * @param {Uint8Array} bytes Stored bytes.
     * @returns {Uint8Array} Decoded bytes.
     */
    decode(bytes) {
        return this._decrypt(bytes);
    },

    /**
     * Encrypts bytes for storage.
     *
     * @param {Uint8Array} bytes Raw bytes.
     * @returns {Uint8Array} Encoded bytes.
     */
    _encrypt(bytes) {
        if (!bytes) return null;
        return bytes;
    },

    /**
     * Decrypts bytes from storage.
     *
     * @param {Uint8Array} bytes Stored bytes.
     * @returns {Uint8Array} Decoded bytes.
     */
    _decrypt(bytes) {
        if (!bytes) return null;
        return bytes;
    },

    /**
     * Parses bytes as text.
     *
     * @param {Uint8Array} bytes Raw bytes to convert.
     * @param {string} [encoding='utf-8'] Character encoding.
     * @returns {string|null} String or null on error.
     */
    parseBytes(bytes, encoding = 'utf-8') {
        if (!bytes) return null;
        try {
            const decrypted = this.decode(bytes);
            const decoder = new TextDecoder(encoding);
            return decoder.decode(decrypted);
        } catch (e) {
            Logger.warn(`ServiceCoreText.parseBytes failed: ${e.message}`);
            return null;
        }
    },

    /**
     * Serializes text to bytes.
     *
     * @param {string} text String to convert.
     * @returns {Uint8Array|null} Bytes or null on error.
     */
    stringifyBytes(text) {
        if (text === null || text === undefined) return null;
        try {
            const encoder = new TextEncoder();
            const bytes = encoder.encode(text);
            return this.encode(bytes);
        } catch (e) {
            Logger.error(`ServiceCoreText.stringifyBytes failed: ${e.message}`);
            return null;
        }
    },

    /**
     * Parses text as text.
     *
     * @param {string} text Input text.
     * @returns {string} Same text.
     */
    parseText(text) {
        return text;
    },

    /**
     * Serializes text to text.
     *
     * @param {string} text Input text.
     * @returns {string} Same text.
     */
    stringifyText(text) {
        return text;
    },
};
