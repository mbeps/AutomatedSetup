const { Gio, GObject } = imports.gi;

const PopupMenu = imports.ui.popupMenu;

const ExtensionUtils = imports.misc.extensionUtils;
const Me = ExtensionUtils.getCurrentExtension();

const { QuickMenuToggle } = Me.imports.quickSettings;
const { loadInterfaceXML } = imports.misc.fileUtils;

const BUS_NAME = 'net.hadess.PowerProfiles';
const OBJECT_PATH = '/net/hadess/PowerProfiles';

const PowerProfilesIface = loadInterfaceXML('net.hadess.PowerProfiles');
const PowerProfilesProxy = Gio.DBusProxy.makeProxyWrapper(PowerProfilesIface);

const PROFILE_PARAMS = {
    'performance': {
        label: C_('Power profile', 'Performance'),
        iconName: 'power-profile-performance-symbolic',
    },

    'balanced': {
        label: C_('Power profile', 'Balanced'),
        iconName: 'power-profile-balanced-symbolic',
    },

    'power-saver': {
        label: C_('Power profile', 'Power Saver'),
        iconName: 'power-profile-power-saver-symbolic',
    },
};

const PowerProfilesItem = GObject.registerClass(
class PowerProfilesItem extends QuickMenuToggle {
    _init() {
        super._init();

        this._profileItems = new Map();
        this._updateProfiles = true;

        this.connect('clicked', () => this.menu.open());

        this._proxy = new PowerProfilesProxy(Gio.DBus.system,
            BUS_NAME, OBJECT_PATH,
            (proxy, error) => {
                if (error) {
                    log(error.message);
                } else {
                    this._proxy.connect('g-properties-changed',
                        (p, properties) => {
                            const propertyNames = properties.deep_unpack();
                            this._updateProfiles = 'Profiles' in propertyNames;
                            this._sync();
                        });
                }
                this._sync();
            });

        this._profileSection = new PopupMenu.PopupMenuSection();
        this.menu.addMenuItem(this._profileSection);

        this._sync();
    }

    _sync() {
        this.visible = this._proxy.g_name_owner !== null;

        if (!this.visible)
            return;

        if (this._updateProfiles) {
            this._profileSection.removeAll();
            this._profileItems.clear();

            const profiles = this._proxy.Profiles
                .map(p => p.Profile.unpack())
                .reverse();
            for (const profile of profiles) {
                const { label } = PROFILE_PARAMS[profile];
                if (!label)
                    continue;

                const item = new PopupMenu.PopupMenuItem(label);
                item.connect('activate',
                    () => (this._proxy.ActiveProfile = profile));
                this._profileItems.set(profile, item);
                this._profileSection.addMenuItem(item);
            }
            this._updateProfiles = false;
        }

        for (const [profile, item] of this._profileItems) {
            item.setOrnament(profile === this._proxy.ActiveProfile
                ? PopupMenu.Ornament.DOT
                : PopupMenu.Ornament.NONE);
        }

        this.set(PROFILE_PARAMS[this._proxy.ActiveProfile]);
        this.checked = this._proxy.ActiveProfile !== 'balanced';
    }
});

var Indicator = class {
    constructor() {
        this.quickSettingsItems = [];

        this.quickSettingsItems.push(new PowerProfilesItem());
    }
};
