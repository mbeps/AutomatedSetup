import St from 'gi://St';
import Clutter from 'gi://Clutter';
import ExtensionFeature from '../../core/extensionFeature.js';
import { GestureRecognizer, GestureRecognizerEvent } from '../../utils/gestures/gestureRecognizer.js';
import { settings } from '../../settings.js';
import { findAllActorsBy } from '../../utils/shellUtils.js';
import Graphene from 'gi://Graphene';
import { isKeyboardKey } from './_oskUtils.js';
import { Ref } from '../../utils/ui/widgets.js';

/** Maximum distance around a key that's still pressable */
const KEY_PRESS_MAX_DISTANCE = 75; // in logical pixels
class OSKGesturesFeature extends ExtensionFeature {
    constructor(pm, keyboard) {
        super(pm);
        if (keyboard) {
            this.onNewKeyboard(keyboard);
        }
    }
    onNewKeyboard(keyboard) {
        const recognizer = new GestureRecognizer({
            onGestureProgress: state => {
                if (settings.osk.gestures.swipeToClose.enabled.get()
                    && state.hasStrongMovement
                    && state.firstMotionDirection?.direction === 'down') {
                    keyboard.gestureProgress(keyboard.height - state.totalMotionDelta.y);
                    // If there is any keyboard key currently pressed, release it:
                    const pressedKey = findAllActorsBy(keyboard, a => a instanceof St.Button && a.pressed).at(0);
                    pressedKey?.fake_release();
                }
            },
            onGestureEnded: state => {
                if (settings.osk.gestures.swipeToClose.enabled.get()
                    && state.hasStrongMovement
                    && state.firstMotionDirection?.direction === 'down'
                    && state.lastMotionDirection?.direction === 'down') {
                    keyboard.gestureCancel();
                }
                else if (settings.osk.gestures.swipeToClose.enabled.get()
                    && keyboard._gestureInProgress) {
                    // The following line is a required hack to make the keyboard animate back up; since the
                    // keyboard's gesture functionality is only intended for opening the keyboard, not for closing,
                    // let alone canceling closing it. Thus, when the swipe-to-close gesture is cancelled, we tell the
                    // keyboard it's not open yet, which perfectly imitates the state it'd be in had we opened it
                    // using the gesture as normal instead of swipe-closing and then cancelling.
                    keyboard._keyboardVisible = false;
                    keyboard.gestureActivate();
                }
            },
        });
        let currentKey = null;
        let pseudoClassPatch = null;
        const onEvent = (evt) => {
            const state = recognizer.push(GestureRecognizerEvent.fromClutterEvent(evt));
            if (state.hasGestureJustStarted && settings.osk.gestures.extendKeys.enabled.get()) {
                const actor = this._selectReactiveChild(keyboard, state.pressCoordinates);
                if (actor?.get_parent() && isKeyboardKey(actor.get_parent())) {
                    currentKey = actor.get_parent();
                }
                if (currentKey
                    && !currentKey.keyButton.get_transformed_extents().contains_point(new Graphene.Point(state.pressCoordinates))) {
                    pseudoClassPatch = this.pm.patch(() => {
                        const key = new Ref(currentKey);
                        key.current.keyButton.add_style_pseudo_class("active");
                        return () => key.take()?.keyButton.remove_style_pseudo_class("active");
                    });
                }
            }
            else if (state.hasStrongMovement) {
                // Cancel keypress:
                currentKey = null;
                if (pseudoClassPatch) {
                    pseudoClassPatch.disable();
                    this.pm.drop(pseudoClassPatch);
                    pseudoClassPatch = null;
                }
            }
            else if (state.hasGestureJustEnded) {
                if (currentKey
                    && !currentKey.keyButton.get_transformed_extents().contains_point(new Graphene.Point(state.pressCoordinates))) {
                    if (state.isTap) {
                        currentKey.keyButton.emit("clicked", evt);
                    }
                }
                currentKey = null;
                if (pseudoClassPatch) {
                    pseudoClassPatch.disable();
                    this.pm.drop(pseudoClassPatch);
                    pseudoClassPatch = null;
                }
            }
        };
        // We have to capture events since the OSK keys listen raw touch events instead of using Clutters new
        // gesture system:
        this.pm.connectTo(keyboard, 'captured-event', (_, evt) => {
            if (!GestureRecognizerEvent.isTouch(evt)) {
                return Clutter.EVENT_PROPAGATE;
            }
            onEvent(evt);
            return Clutter.EVENT_PROPAGATE; // Clutter.EVENT_STOP;
        });
    }
    /**
     * Returns the reactive actor on the keyboard that is closest to the given position, unless the position
     * is more than [KEY_PRESS_MAX_DISTANCE] off the key.
     */
    _selectReactiveChild(keyboard, point) {
        const maxDist = KEY_PRESS_MAX_DISTANCE * St.ThemeContext.get_for_stage(global.stage).scaleFactor;
        const graphenePoint = new Graphene.Point(point);
        const candidates = findAllActorsBy(keyboard, (a) => a.mapped && a.reactive);
        const hitActor = candidates.find(key => key
            .get_transformed_extents()
            .contains_point(graphenePoint));
        if (hitActor)
            return hitActor;
        const nearest = candidates.reduce((a, b) => {
            const distA = a.get_transformed_extents().get_center().distance(graphenePoint)[0];
            const distB = b.get_transformed_extents().get_center().distance(graphenePoint)[0];
            return distA < distB ? a : b;
        });
        if (nearest.get_transformed_extents().get_center().distance(graphenePoint)[0] > maxDist) {
            return null;
        }
        return nearest ?? null;
    }
}

export { OSKGesturesFeature };
