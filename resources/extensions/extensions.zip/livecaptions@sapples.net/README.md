# Live Captions Assistant for GNOME

This is a simple GNOME extension that allows the Live Captions window to always keep on top, even on GNOME Wayland.