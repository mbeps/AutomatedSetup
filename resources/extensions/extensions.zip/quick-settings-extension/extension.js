/* extension.js
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

/* exported init */

const GETTEXT_DOMAIN = 'my-indicator-extension';

const { Clutter, Gio, GObject, Shell, St, UPowerGlib: UPower } = imports.gi;

const ExtensionUtils = imports.misc.extensionUtils;
const Main = imports.ui.main;
const PopupMenu = imports.ui.popupMenu;

const _ = ExtensionUtils.gettext;
const Me = ExtensionUtils.getCurrentExtension();

const { QuickSettingsMenu, QuickMenuToggle } = Me.imports.quickSettings;

const N_COLUMNS = 2;

class DemoMenu extends QuickSettingsMenu {
    constructor(sourceActor) {
        super(sourceActor, N_COLUMNS);

        globalThis.quickSettings = this; // hack for quick access in lg

        this._system = new Me.imports.status.system.Indicator();
        this._volume = new Me.imports.status.volume.Indicator();
        this._brightness = new Me.imports.status.brightness.Indicator();
        this._nightLight = new Me.imports.status.nightLight.Indicator();
        this._network = new Me.imports.status.network.Indicator();
        this._bluetooth = new Me.imports.status.bluetooth.Indicator();
        this._darkMode = new Me.imports.status.darkMode.Indicator();
        this._powerProfiles = new Me.imports.status.powerProfiles.Indicator();
        this._rfkill = new Me.imports.status.rfkill.Indicator();
        this._autoRotate = new Me.imports.status.autoRotate.Indicator();

        this._addItems(this._system.quickSettingsItems, N_COLUMNS);
        this._addItems(this._volume.quickSettingsItems, N_COLUMNS);
        this._addItems(this._brightness.quickSettingsItems, N_COLUMNS);

        this._addItems(this._network.quickSettingsItems);
        this._addItems(this._bluetooth.quickSettingsItems);
        this._addItems(this._nightLight.quickSettingsItems);
        this._addItems(this._darkMode.quickSettingsItems);
        this._addItems(this._powerProfiles.quickSettingsItems);
        this._addItems(this._rfkill.quickSettingsItems);
        this._addItems(this._autoRotate.quickSettingsItems);
    }

    _addItems(items, colSpan = 1) {
        items.forEach(item => this.addItem(item, colSpan));
    }
}

class Extension {
    constructor() {
        ExtensionUtils.initTranslations(GETTEXT_DOMAIN);
    }

    enable() {
        this._remoteAccess = new Me.imports.remoteAccess.RemoteAccessApplet();
        Main.panel.addToStatusArea('remote-access', this._remoteAccess);

        const aggregate = Main.panel.statusArea.aggregateMenu;
        this._savedMenu = aggregate.menu;
        aggregate.menu = null;

        this._quickSettings = new DemoMenu(aggregate);
        aggregate.setMenu(this._quickSettings);

        this._removeMenu(this._savedMenu);
        this._addMenu(this._quickSettings);

        Main.panel.closeQuickSettings = () => this._quickSettings.close();
    }

    disable() {
        this._remoteAccess.destroy();

        const aggregate = Main.panel.statusArea.aggregateMenu;
        aggregate.setMenu(this._savedMenu);
        this._addMenu(this._savedMenu);

        this._quickSettings = null;
        this._savedMenu = null;

        delete Main.panel.closeQuickSettings;
    }

    _addMenu(menu) {
        Main.panel.menuManager.addMenu(menu);
    }

    _removeMenu(menu) {
        Main.panel.menuManager.removeMenu(menu);
        Main.uiGroup.remove_child(menu.actor);
    }
}

function init() {
    return new Extension();
}
