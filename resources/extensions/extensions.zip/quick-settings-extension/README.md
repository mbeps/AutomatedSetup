# Quick Settings

[Get it here](https://gitlab.gnome.org/fmuellner/quick-settings-extension/-/jobs/artifacts/main/raw/quick-settings@fmuellner.gnome.org.shell-extension.zip?job=build-bundles)
