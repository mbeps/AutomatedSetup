const { Gio, GObject } = imports.gi;

const PopupMenu = imports.ui.popupMenu;

const ExtensionUtils = imports.misc.extensionUtils;
const Me = ExtensionUtils.getCurrentExtension();

const { QuickMenuToggle } = Me.imports.quickSettings;
const { loadInterfaceXML } = imports.misc.fileUtils;

const BUS_NAME = 'net.hadess.PowerProfiles';
const OBJECT_PATH = '/net/hadess/PowerProfiles';

const PowerProfilesIface = loadInterfaceXML('net.hadess.PowerProfiles');
const PowerProfilesProxy = Gio.DBusProxy.makeProxyWrapper(PowerProfilesIface);

const PROFILE_PARAMS = {
    'performance': {
        label: C_('Power profile', 'Performance'),
        iconName: 'power-profile-performance-symbolic',
    },

    'balanced': {
        label: C_('Power profile', 'Balanced'),
        iconName: 'power-profile-balanced-symbolic',
    },

    'power-saver': {
        label: C_('Power profile', 'Power Saver'),
        iconName: 'power-profile-power-saver-symbolic',
    },
};

const PowerProfilesItem = GObject.registerClass(
class PowerProfilesItem extends QuickMenuToggle {
    _init() {
        super._init();

        this._profileItems = new Map();

        mySettings.connect('changed::last-power-profile',
            () => (this._lastProfile = mySettings.get_string('last-power-profile')));
        this._lastProfile = mySettings.get_string('last-power-profile');

        this.connect('clicked', () => {
            if (this.checked)
                this._proxy.ActiveProfile = 'balanced';
            else if (this._lastProfile)
                this._proxy.ActiveProfile = this._lastProfile;

        });

        this._proxy = new PowerProfilesProxy(Gio.DBus.system,
            BUS_NAME, OBJECT_PATH,
            (proxy, error) => {
                if (error) {
                    log(error.message);
                } else {
                    this._proxy.connect('g-properties-changed',
                        (p, properties) => {
                            const propertyNames = properties.deep_unpack();
                            if ('Profiles' in propertyNames)
                                this._syncProfiles();
                            this._sync();
                        });
                    this._syncProfiles();
                }
                this._sync();
            });

        this._profileSection = new PopupMenu.PopupMenuSection();
        this.menu.addMenuItem(this._profileSection);
        this.menu.setHeader('power-profile-balanced-symbolic', _('Power Profiles'));

        this._sync();
    }

    _syncProfiles() {
        this._profileSection.removeAll();
        this._profileItems.clear();

        const profiles = this._proxy.Profiles
            .map(p => p.Profile.unpack())
            .reverse();
        for (const profile of profiles) {
            const {label, iconName} = PROFILE_PARAMS[profile];
            if (!label)
                continue;

            const item = new PopupMenu.PopupImageMenuItem(label, iconName);
            item.connect('activate',
                () => (this._proxy.ActiveProfile = profile));
            this._profileItems.set(profile, item);
            this._profileSection.addMenuItem(item);
        }
    }

    _sync() {
        this.visible = this._proxy.g_name_owner !== null;

        if (!this.visible)
            return;

        const {ActiveProfile: activeProfile} = this._proxy;

        for (const [profile, item] of this._profileItems) {
            item.setOrnament(profile === activeProfile
                ? PopupMenu.Ornament.CHECK
                : PopupMenu.Ornament.NONE);
        }

        this.set(PROFILE_PARAMS[activeProfile]);
        this.checked = activeProfile !== 'balanced';

        if (this.checked)
            mySettings.set_string('last-power-profile', activeProfile);
    }
});

var Indicator = class {
    constructor() {
        this.quickSettingsItems = [];

        this.quickSettingsItems.push(new PowerProfilesItem());
    }
};
