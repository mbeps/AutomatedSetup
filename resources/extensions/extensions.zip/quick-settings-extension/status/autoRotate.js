const { Gio, GObject } = imports.gi;

const SystemActions = imports.misc.systemActions;

const ExtensionUtils = imports.misc.extensionUtils;
const Me = ExtensionUtils.getCurrentExtension();

const { QuickToggle } = Me.imports.quickSettings;

const RotationToggle = GObject.registerClass(
class RotationToggle extends QuickToggle {
    _init() {
        this._systemActions = new SystemActions.getDefault();

        super._init({
            label: 'Auto Rotate',
        });

        this._systemActions.bind_property('can-lock-orientation',
            this, 'visible',
            GObject.BindingFlags.DEFAULT |
            GObject.BindingFlags.SYNC_CREATE);
        this._systemActions.bind_property('orientation-lock-icon',
            this, 'icon-name',
            GObject.BindingFlags.DEFAULT |
            GObject.BindingFlags.SYNC_CREATE);

        this._settings = new Gio.Settings({
            schema_id: 'org.gnome.settings-daemon.peripherals.touchscreen',
        });
        this._settings.bind('orientation-lock',
            this, 'checked',
            Gio.SettingsBindFlags.DEFAULT);

        this.connect('clicked',
            () => this._systemActions.activateLockOrientation());
    }
});

var Indicator = class {
    constructor() {
        this.quickSettingsItems = [];

        this.quickSettingsItems.push(new RotationToggle());
    }
};
