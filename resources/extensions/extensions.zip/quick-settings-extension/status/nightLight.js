// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-
/* exported Indicator */

const { Gio, GObject } = imports.gi;

const ExtensionUtils = imports.misc.extensionUtils;
const Me = ExtensionUtils.getCurrentExtension();

const { QuickToggle } = Me.imports.quickSettings;

const NightLightToggle = GObject.registerClass(
class NightLightToggle extends QuickToggle {
    _init() {
        super._init({
            label: 'Night Light',
            iconName: 'night-light-symbolic',
            toggleMode: true,
        });

        this._settings = new Gio.Settings({
            schema_id: 'org.gnome.settings-daemon.plugins.color',
        });
        this._settings.bind('night-light-enabled',
            this, 'checked',
            Gio.SettingsBindFlags.DEFAULT);
    }
});

var Indicator = class {
    constructor() {
        this.quickSettingsItems = [];

        this.quickSettingsItems.push(new NightLightToggle());
    }
};
