const { Atk, Clutter, Gio, GLib, GObject, Meta, NM, Polkit, St } = imports.gi;

const PopupMenu = imports.ui.popupMenu;
const ExtensionUtils = imports.misc.extensionUtils;
const Me = ExtensionUtils.getCurrentExtension();
const { TransientSignalHolder } = imports.misc.signalTracker;
const ModemManager = imports.misc.modemManager;

const {Spinner} = imports.ui.animation;
const { QuickMenuToggle } = Me.imports.quickSettings;

// small optimization, to avoid using [] all the time
const NM80211Mode = NM['80211Mode'];
const NM80211ApFlags = NM['80211ApFlags'];
const NM80211ApSecurityFlags = NM['80211ApSecurityFlags'];

const WIFI_SCAN_FREQUENCY = 15;
const MAX_VISIBLE_WIFI_NETWORKS = 8;

Gio._promisify(NM.DeviceWifi.prototype, 'request_scan_async');

function launchSettingsPanel(panel, ...args) {
    const param = new GLib.Variant('(sav)',
        [panel, args.map(s => new GLib.Variant('s', s))]);
    const platformData = {
        'desktop-startup-id': new GLib.Variant('s',
            `_TIME${global.get_current_time()}`),
    };
    try {
        Gio.DBus.session.call(
            'org.gnome.Settings',
            '/org/gnome/Settings',
            'org.freedesktop.Application',
            'ActivateAction',
            new GLib.Variant('(sava{sv})',
                ['launch-panel', [param], platformData]),
            null,
            Gio.DBusCallFlags.NONE,
            -1,
            null);
    } catch (e) {
        log(`Failed to launch Settings panel: ${e.message}`);
    }
}

/**
 * @param {number} strength
 * @returns {string}
 */
function getWifiStrengthIcon(strength) {
    let qualifier;
    if (strength < 20)
        qualifier = 'none';
    else if (strength < 40)
        qualifier = 'weak';
    else if (strength < 50)
        qualifier = 'ok';
    else if (strength < 80)
        qualifier = 'good';
    else
        qualifier = 'excellent';
    return `network-wireless-signal-${qualifier}-symbolic`;
}

const WirelessNetwork = GObject.registerClass({
    Properties: {
        'name': GObject.ParamSpec.string(
            'name', '', '',
            GObject.ParamFlags.READABLE,
            ''),
        'icon-name': GObject.ParamSpec.string(
            'icon-name', '', '',
            GObject.ParamFlags.READABLE,
            ''),
        'secure': GObject.ParamSpec.boolean(
            'secure', '', '',
            GObject.ParamFlags.READABLE,
            false),
        'is-active': GObject.ParamSpec.boolean(
            'is-active', '', '',
            GObject.ParamFlags.READABLE,
            false),
    },
}, class WirelessNetwork extends GObject.Object {
    static _securityTypes =
        Object.values(NM.UtilsSecurityType).sort((a, b) => b - a);

    _init(device) {
        super._init();

        this._device = device;

        this._accessPoints = new Set();
        this._connections = [];
        this._name = '';
        this._ssid = null;
        this._bestAp = null;
        this._mode = 0;
        this._securityType = NM.UtilsSecurityType.NONE;
    }

    get name() {
        return this._name;
    }

    get icon_name() {
        if (this._mode === NM80211Mode.ADHOC)
            return 'network-workgroup-symbolic';

        if (!this._bestAp)
            return '';

        return getWifiStrengthIcon(this._bestAp.strength);
    }

    get secure() {
        return this._securityType !== NM.UtilsSecurityType.NONE;
    }

    get is_active() {
        return this._accessPoints.has(this._device.activeAccessPoint);
    }

    hasAccessPoint(ap) {
        return this._accessPoints.has(ap);
    }

    hasAccessPoints() {
        return this._accessPoints.size > 0;
    }

    checkAccessPoint(ap) {
        if (!ap.get_ssid())
            return false;

        const secType = this._getApSecurityType(ap);
        if (secType === NM.UtilsSecurityType.INVALID)
            return false;

        if (this._accessPoints.size === 0)
            return true;

        return this._ssid.equal(ap.ssid) &&
            this._mode === ap.mode &&
            this._securityType === secType;
    }

    /**
     * @param {NM.AccessPoint} ap - an access point
     * @return {bool} - whether the access point was added
     */
    addAccessPoint(ap) {
        if (!this.checkAccessPoint(ap))
            return false;

        if (this._accessPoints.size === 0) {
            this._ssid = ap.get_ssid();
            this._mode = ap.mode;
            this._securityType = this._getApSecurityType(ap);
            this._name = NM.utils_ssid_to_utf8(this._ssid.get_data()) || '<unknown>';

            this.notify('name');
            this.notify('secure');
        }

        this.notify('is-active');

        this._accessPoints.add(ap);
        this._updateBestAp();

        return true;
    }

    /**
     * @param {NM.AccessPoint} ap - an access point
     * @return {bool} - whether the access point was removed
     */
    removeAccessPoint(ap) {
        if (!this._accessPoints.delete(ap))
            return false;

        this._updateBestAp();
        return true;
    }

    /**
     * @param {WirelessNetwork} other - network to compare with
     * @return {number} - the sort order
     */
    compare(other) {
        // place known connections first
        const hasConn1 = this._connections.length > 0;
        const hasConn2 = other._connections.length > 0;
        const cmpConnections = hasConn2 - hasConn1;
        if (cmpConnections !== 0)
            return cmpConnections;

        const cmpAps = other.hasAccessPoints() - this.hasAccessPoints();
        if (cmpAps !== 0)
            return cmpAps;

        // place stronger connections first
        const cmpStrength = other._bestAp.strength - this._bestAp.strength;
        if (cmpStrength !== 0)
            return cmpStrength;

        // place secure connections first
        const cmpSec = other.secure - this.secure;
        if (cmpSec !== 0)
            return cmpSec;

        // sort alphabetically
        return GLib.utf8_collate(this._name, other._name);
    }

    checkConnections(connections) {
        const hadConnections = this._connections.length > 0;
        const aps = [...this._accessPoints];
        this._connections = connections.filter(
            c => aps.some(ap => ap.connection_valid(c)));
    }

    activate() {
        const [ap] = this._accessPoints;
        const canAutoconnect =
            this._securityTypes !== NM.UtilsSecurityType.WPA_ENTERPRISE &&
            this._securityTypes !== NM.UtilsSecurityType.WPA2_ENTERPRISE;

        let [conn] = this._connections;
        if (conn) {
            this._device.client.activate_connection_async(conn, this._device, null, null, null);
        } else if (!canAutoconnect) {
            launchSettingsPanel('wifi', 'connect-8021x-wifi',
                this._getDeviceDBusPath(), ap.get_path());
        } else {
            conn = new NM.SimpleConnection();
            this._device.client.add_and_activate_connection_async(
                conn, this._device, ap.get_path(), null, null);
        }
    }

    _getDeviceDBusPath() {
        // nm_object_get_path() is shadowed by nm_device_get_path()
        return NM.Object.prototype.get_path.call(this._device);
    }

    _getApSecurityType(ap) {
        const {wirelessCapabilities: caps} = this._device;
        const {flags, wpaFlags, rsnFlags} = ap;
        const haveAp = true;
        const adHoc = ap.mode === NM80211Mode.ADHOC;
        const bestType = WirelessNetwork._securityTypes
            .find(t => NM.utils_security_valid(t, caps, haveAp, adHoc, flags, wpaFlags, rsnFlags));
        return bestType ?? NM.UtilsSecurityType.INVALID;
    }

    _updateBestAp() {
        const [bestAp] =
            [...this._accessPoints].sort((a, b) => b.strength - a.strength);

        if (this._bestAp === bestAp)
            return;

        this._bestAp = bestAp;
        this.notify('icon-name');
    }
});

const NMMenuItem = GObject.registerClass({
    GTypeFlags: GObject.TypeFlags.ABSTRACT,
    Properties: {
        'state': GObject.ParamSpec.enum('state', '', '',
            GObject.ParamFlags.READABLE,
            NM.ActiveConnectionState,
            NM.ActiveConnectionState.DEACTIVATED),
        'is-active': GObject.ParamSpec.boolean(
            'is-active', '', '',
            GObject.ParamFlags.READABLE,
            false),
        'icon-name': GObject.ParamSpec.string('icon-name', '', '',
            GObject.ParamFlags.READABLE,
            ''),
        'label': GObject.ParamSpec.string('label', '', '',
            GObject.ParamFlags.READABLE,
            ''),
    },
}, class NMMenuItem extends PopupMenu.PopupBaseMenuItem {
    _init(params = {}) {
        super._init(params);

        this._activeConnection = null;
    }

    get state() {
        return this._activeConnection?.state ??
            NM.ActiveConnectionState.DEACTIVATED;
    }

    get is_active() {
        return this.isActive;
    }

    get isActive() {
        return this.state <= NM.ActiveConnectionState.ACTIVATED;
    }

    get icon_name() {
        return this.iconName;
    }

    get iconName() {
        return '';
    }

    get label() {
        return '';
    }

    activate() {
        super.activate(Clutter.get_current_event());
    }

    _activeConnectionStateChanged() {
        this.notify('state');
        this.notify('is-active');
        this.notify('icon-name');
        this.notify('label');
    }

    _setActiveConnection(activeConnection) {
        this._activeConnection?.disconnectObject(this);

        this._activeConnection = activeConnection;

        this._activeConnection?.connectObject(
            'notify::state', () => this._activeConnectionStateChanged(), this);
        this._activeConnectionStateChanged();
    }
});

const DeviceMenuItem = GObject.registerClass(
class DeviceMenuItem extends NMMenuItem {
    _init(device) {
        super._init({
            activate: false,
        });

        this._device = device;
        this._disableSubmenu = false;

        this._connectionItems = new Map();

        // Turn into an empty container with no padding
        this.styleClass = '';
        this.setOrnament(PopupMenu.Ornament.HIDDEN);

        // Add intermediate section; we need this for submenu support
        this._mainSection = new PopupMenu.PopupMenuSection();
        this.add_child(this._mainSection.actor);

        // Submenu that represents the device if either
        //  - there is more than one connection
        //  - disableSubmenu is false
        this._submenuItem = new PopupMenu.PopupSubMenuMenuItem('', true);
        this._mainSection.addMenuItem(this._submenuItem);
        this._submenuItem.hide();

        // Represents the device as a whole when shown
        this.bind_property('label',
            this._submenuItem.label, 'text',
            GObject.BindingFlags.SYNC_CREATE);
        this.bind_property('icon-name',
            this._submenuItem.icon, 'icon-name',
            GObject.BindingFlags.SYNC_CREATE);

        // Section that represent the device if either
        //  - there are 1 or 0 connections
        //  - disableSubmenu is true
        this._connectionSection = new PopupMenu.PopupMenuSection();
        this._mainSection.addMenuItem(this._connectionSection);

        // Item shown in the 0-connections case
        this._autoConnectItem =
            this._connectionSection.addAction('', () => this._autoConnect(), '');

        // Represents the device as a whole when shown
        this.bind_property('label',
            this._autoConnectItem.label, 'text',
            GObject.BindingFlags.SYNC_CREATE);
        this.bind_property('icon-name',
            this._autoConnectItem._icon, 'icon-name',
            GObject.BindingFlags.SYNC_CREATE);

        this._device.connectObject(
            'notify::available-connections', () => this._syncConnections(),
            'notify::active-connection', () => this._activeConnectionChanged(),
            this);

        this._syncConnections();
        this._activeConnectionChanged();
    }

    _setParent(parent) {
        super._setParent(parent);
        this._mainSection._setParent(parent);

        parent?.connect('menu-closed',
            () => this._mainSection.emit('menu-closed'));
    }

    get _radioMode() {
        return this._connectionItems.size > 1;
    }

    set disableSubmenu(disable) {
        if (this._disableSubmenu === disable)
            return;

        this._disableSubmenu = disable;
        this._sync();
    }

    get label() {
        if (this._radioMode) {
            if (this._activeConnection)
                return this._activeConnection.get_id();
            if (this.lastConnection)
                return this.lastConnection.get_id();
        }
        return this._deviceName;
    }

    get lastConnection() {
        const uuid = mySettings.get_string(this.constructor['LAST_CONNECTION_KEY']);
        const conn = this._device.client?.get_connection_by_uuid(uuid);
        if (conn && this._device.connection_valid(conn))
            return conn;

        return null;
    }

    setDeviceName(name) {
        this._deviceName = name;
        this.notify('label');
    }

    _getActivatableConnection() {
        // if we have an active connection, we can toggle it
        let { connection } = this._activeConnection ?? {};
        if (connection)
            return connection;

        // otherwise, try the last used connection
        connection = this.lastConnection;
        if (connection)
            return connection;

        // lastly if we only have 1 connection, that's unambiguous
        if (this._connectionItems.size === 1)
            [[connection]] = this._connectionItems;
        else
            connection = null;

        return connection ?? null;
    }

    activate() {
        const conn = this._getActivatableConnection();

        if (conn)
            this._toggleConnection(conn);
        else if (this._autoConnectItem.visible)
            this._autoConnect();
        else
            return;

        super.activate();
    }

    _autoConnect() {
        const connection = new NM.SimpleConnection();
        this._activateConnection(connection);
    }

    _toggleConnection(conn) {
        const { client } = this._device;

        if (!this._activeConnection)
            client.activate_connection_async(conn, this._device, null, null, null);
        else
            this._device.disconnect(null);
    }

    _activateConnection(conn) {
        const { client } = this._device;

        if (this._connectionItems.size === 1)
            this._toggleConnection(conn)
        else if (this._activeConnection?.connection !== conn)
            client.activate_connection_async(conn, this._device, null, null, null);
    }

    _addConnection(conn) {
        const label = conn.get_id();
        const submenuItem = this._submenuItem.menu.addAction(label,
            () => this._activateConnection(conn));
        const sectionItem = this._connectionSection.addAction(label,
            () => this._activateConnection(conn), '');

        this.bind_property('icon-name',
            sectionItem._icon, 'icon-name',
            GObject.BindingFlags.SYNC_CREATE);

        this._connectionItems.set(conn, { submenuItem, sectionItem });
    }

    _removeConnection(conn) {
        const { sectionItem, submenuItem } = this._connectionItems.get(conn) ?? {};
        sectionItem?.destroy();
        submenuItem?.destroy();
        this._connectionItems.delete(conn);
    }

    _syncConnections() {
        const oldRadioMode = this._radioMode;

        const available = this._device.get_available_connections();
        for (const [conn] of this._connectionItems) {
            if (!available.includes(conn))
                this._removeConnection(conn);
        }

        for (const conn of available) {
            if (!this._connectionItems.has(conn))
                this._addConnection(conn);
        }

        if (oldRadioMode !== this._radioMode)
            this.notify('label');

        this._syncOrnament();

        // If we have a single connection, it represents the device as a whole
        // and should get an icon
        const iconVisible = !this._radioMode;
        for (const { sectionItem } of this._connectionItems.values())
            sectionItem._icon.visible = iconVisible;

        this._sync();
    }

    _syncOrnament() {
        const { isActive } = this;
        const useDot = isActive && this._radioMode;
        this._connectionItems.forEach(({ submenuItem, sectionItem }, conn) => {
            const ornament = useDot && this._activeConnection?.connection === conn
                ? PopupMenu.Ornament.DOT
                : PopupMenu.Ornament.NONE;
            submenuItem.setOrnament(ornament);
            sectionItem.setOrnament(ornament);
        });
    }

    _saveLastConnection() {
        mySettings.set_string(this.constructor['LAST_CONNECTION_KEY'],
            this._activeConnection.uuid);
    }

    _activeConnectionStateChanged() {
        super._activeConnectionStateChanged();

        if (this.state === NM.ActiveConnectionState.ACTIVATED)
            this._saveLastConnection();

        this._syncOrnament();
    }

    _activeConnectionChanged() {
        this._setActiveConnection(this._device.active_connection);
    }

    _sync() {
        const nItems = this._connectionItems.size;
        const useSubmenu = this._radioMode && !this._disableSubmenu;
        this._autoConnectItem.visible = nItems === 0;
        this._submenuItem.visible = useSubmenu;
        this._connectionSection.visible = !useSubmenu;
    }
});

const WirelessNetworkItem = GObject.registerClass(
class WirelessNetworkItem extends PopupMenu.PopupBaseMenuItem {
    _init(network) {
        super._init();

        this._network = network;

        const icons = new St.BoxLayout();
        this.add_child(icons);

        this._signalIcon = new St.Icon({
            style_class: 'quick-toggle-icon',
        });
        icons.add_child(this._signalIcon);

        this._secureIcon = new St.Icon({
            style_class: 'wireless-secure-icon',
            x_align: Clutter.ActorAlign.START,
            y_align: Clutter.ActorAlign.END,
        });
        icons.add_child(this._secureIcon);

        this._label = new St.Label();
        this.add_child(this._label);

        this._selectedIcon = new St.Icon({
            style_class: 'quick-toggle-icon',
            icon_name: 'object-select-symbolic',
        });
        this.add_child(this._selectedIcon);

        this._network.bind_property('icon-name',
            this._signalIcon, 'icon-name',
            GObject.BindingFlags.SYNC_CREATE);
        this._network.bind_property('name',
            this._label, 'text',
            GObject.BindingFlags.SYNC_CREATE);
        this._network.bind_property('is-active',
            this._selectedIcon, 'visible',
            GObject.BindingFlags.SYNC_CREATE);
        this._network.bind_property_full('secure',
            this._secureIcon, 'icon-name',
            GObject.BindingFlags.SYNC_CREATE,
            (bind, source) => [true, source ? 'network-wireless-encrypted-symbolic' : ''],
            null);
    }
});

const WirelessDeviceMenuItem = GObject.registerClass(
class WirelessDeviceMenuItem extends NMMenuItem {
    _init(device) {
        super._init({
            activate: false,
        });

        this._device = device;
        this._deviceName = '';
        this._disableSubmenu = false;

        this._networkItems = new Map();

        // Turn into an empty container with no padding
        this.styleClass = '';
        this.setOrnament(PopupMenu.Ornament.HIDDEN);

        // Add intermediate section; we need this for submenu support
        this._mainSection = new PopupMenu.PopupMenuSection();
        this.add_child(this._mainSection.actor);

        // Submenu that represents the device if either
        //  - there is more than one connection
        //  - disableSubmenu is false
        this._submenuItem = new PopupMenu.PopupSubMenuMenuItem('', true);
        this._mainSection.addMenuItem(this._submenuItem);
        this._submenuItem.hide();

        // Represents the device as a whole when shown
        this.bind_property('label',
            this._submenuItem.label, 'text',
            GObject.BindingFlags.SYNC_CREATE);
        this.bind_property('icon-name',
            this._submenuItem.icon, 'icon-name',
            GObject.BindingFlags.SYNC_CREATE);

        // Section that represent the device if either
        //  - there are 1 or 0 connections
        //  - disableSubmenu is true
        this._connectionSection = new PopupMenu.PopupMenuSection();
        this._mainSection.addMenuItem(this._connectionSection);

        /* set up aps */
        this._device.connectObject(
            'notify::active-access-point', () => this._activeAccessPointChanged(),
            'notify::active-connection', () => this._activeConnectionChanged(),
            'notify::available-connections', () => this._availableConnectionsChanged(),
            'access-point-added', (d, ap) => {
                this._addAccessPoint(ap);
                this._syncNetworksList();
            },
            'access-point-removed', (d, ap) => {
                this._removeAccessPoint(ap);
                this._syncNetworksList();
            },
            this);

        this._device.client.connectObject(
            'notify::connectivity', () => this.notify('icon-name'),
            'notify::wireless-enabled', () => this.notify('icon-name'),
            this);

        for (const ap of this._device.get_access_points())
            this._addAccessPoint(ap);

        this._syncNetworksList();
        this._activeConnectionChanged();
        this._availableConnectionsChanged();
    }

    _setParent(parent) {
        super._setParent(parent);
        this._mainSection._setParent(parent);

        parent?.connect('menu-closed',
            () => this._mainSection.emit('menu-closed'));
    }

    _canReachInternet() {
        const { client } = this._device;
        if (client.primary_connection !== this._device.active_connection)
            return true;

        return client.connectivity === NM.ConnectivityState.FULL;
    }

    set disableSubmenu(disable) {
        if (this._disableSubmenu === disable)
            return;

        this._disableSubmenu = disable;
        this._sync();
    }

    _getSignalStrengthIcon() {
        const { activeAccessPoint } = this._device;
        if (!activeAccessPoint)
            return 'network-wireless-signal-none-symbolic';

        return getWifiStrengthIcon(activeAccessPoint.strength);
    }

    get label() {
        if (this.isHotspot)
            return _('Wi–Fi Hotspot');

        const activeNetwork = [...this._networkItems.keys()].find(n => n.isActive);
        return activeNetwork?.name ?? this._deviceName;
    }

    get iconName() {
        if (!this._device.client.wireless_enabled)
            return 'network-wireless-disabled-symbolic';

        switch (this.state) {
        case NM.ActiveConnectionState.ACTIVATING:
            return 'network-wireless-acquiring-symbolic';

        case NM.ActiveConnectionState.ACTIVATED:
            if (this.isHotspot)
                return 'network-wireless-hotspot-symbolic';

            const { activeAccessPoint } = this._device;
            if (!activeAccessPoint) {
                if (this._device.mode !== NM80211Mode.ADHOC)
                    log('An active wireless connection, in infrastructure mode, involves no access point?');

                if (this._canReachInternet())
                    return 'network-wireless-connected-symbolic';
                else
                    return 'network-wireless-no-route-symbolic';
            }

            if (this._canReachInternet())
                return this._getSignalStrengthIcon();
            else
                return 'network-wireless-no-route-symbolic';
        default:
            return 'network-wireless-signal-none-symbolic';
        }
    }

    get isHotspot() {
        if (!this._device.active_connection)
            return false;

        let connection = this._device.active_connection.connection;
        if (!connection)
            return false;

        let ip4config = connection.get_setting_ip4_config();
        if (!ip4config)
            return false;

        return ip4config.get_method() === NM.SETTING_IP4_CONFIG_METHOD_SHARED;
    }

    setDeviceName(name) {
        this._deviceName = name;
        this.notify('label');
    }

    activate() {
        if (!this.isHotspot)
            return;

        const {client} = this._device;
        client.deactivate_connection_async(this._activeConnection, null, null);
    }

    _activeAccessPointChanged() {
        this.notify('label');
        this.notify('icon-name');

        // This is a layer violation, but allows us to
        // not connect any signals from the network object,
        // which doesn't have a good cleanup point
        for (const net of this._networkItems.keys())
            net.notify('is-active');
    }

    _activeConnectionChanged() {
        this._setActiveConnection(this._device.active_connection);
    }

    _availableConnectionsChanged() {
        const connections = this._device.get_available_connections();
        for (const net of this._networkItems.keys())
            net.checkConnections(connections);
        this._syncNetworksList();
    }

    _addAccessPoint(ap) {
        if (!ap.ssid) {
            // The access point is not visible yet;
            // wait for it to get an ssid
            ap.connectObject('notify::ssid', () => {
                if (!ap.ssid)
                    return;
                ap.disconnectObject(this);
                this._addAccessPoint(ap);
            }, this);
            return;
        }

        let network = [...this._networkItems.keys()]
            .find(n => n.checkAccessPoint(ap));

        if (!network) {
            network = new WirelessNetwork(this._device);

            const item = new WirelessNetworkItem(network);
            item.connect('activate', () => network.activate());
            this._connectionSection.addMenuItem(item);
            this._networkItems.set(network, item);
        }

        network.addAccessPoint(ap);
    }

    _syncNetworksList() {
        const {box} = this._connectionSection;
        const sortedItems = [...this._networkItems]
            .sort(([net1], [net2]) => net1.compare(net2))
            .map(([net, item]) => item);

        for (const [index, item] of sortedItems.entries()) {
            box.set_child_at_index(item, index);
            item.visible = index < MAX_VISIBLE_WIFI_NETWORKS;
        }
    }

    _removeAccessPoint(ap) {
        const network = [...this._networkItems.keys()]
            .find(n => n.removeAccessPoint(ap));

        if (!network || network.hasAccessPoints())
            return;

        this._networkItems.get(network)?.destroy();
        this._networkItems.delete(network);
    }

    _sync() {
        /*
        const nItems = this._networkItems.size;
        const useSubmenu = nItems > 1 && !this._disableSubmenu;
        this._submenuItem.visible = useSubmenu;
        this._connectionSection.visible = !useSubmenu;
        */
    }
});

const WiredDeviceMenuItem = GObject.registerClass(
class WiredDeviceMenuItem extends DeviceMenuItem {
    static LAST_CONNECTION_KEY = 'nm-connections-last-wired';

    _init(device) {
        super._init(device);

        this._device.client.connectObject(
            'notify::connectivity', () => this.notify('icon-name'),
            this);
    }

    get iconName() {
        switch (this.state) {
        case NM.ActiveConnectionState.ACTIVATING:
            return 'network-wired-acquiring-symbolic';
        case NM.ActiveConnectionState.ACTIVATED:
            return this._canReachInternet()
                ? 'network-wired-symbolic'
                : 'network-wired-no-route-symbolic';
        default:
            return 'network-wired-disconnected-symbolic';
        }
    }

    _canReachInternet() {
        const { client } = this._device;
        if (client.primary_connection !== this._device.active_connection)
            return true;

        return client.connectivity === NM.ConnectivityState.FULL;
    }
});

const BtDeviceMenuItem = GObject.registerClass(
class BtDeviceMenuItem extends DeviceMenuItem {
    static LAST_CONNECTION_KEY = 'nm-connections-last-bluetooth';

    // BT's uuids are only stable while the adapter is powered on;
    // work around this by storing the hw-address instead. I *think*
    // BT devices only allow for a single connection, so this should
    // work out okay-ish
    _saveLastConnection() {
        mySettings.set_string(this.constructor['LAST_CONNECTION_KEY'],
            this._device.hw_address);
    }

    get lastConnection() {
        const hwAddress =
            mySettings.get_string(this.constructor['LAST_CONNECTION_KEY']);
        if (hwAddress !== this._device.hw_address)
            return null;
        const [conn] = this._device.get_available_connections();
        return conn ?? null;
    }

    get label() {
        return this._device.name || this._deviceName;
    }

    get iconName() {
        if (!this._activeConnection)
            return 'network-cellular-disabled-symbolic';

        switch (this.state) {
        case NM.ActiveConnectionState.ACTIVATING:
            return 'network-cellular-acquiring-symbolic';
        case NM.ActiveConnectionState.ACTIVATED:
            return 'network-cellular-connected-symbolic';
        default:
            return 'network-cellular-signal-none-symbolic';
        }
    }
});

const ModemDeviceMenuItem = GObject.registerClass(
class ModemDeviceMenuItem extends DeviceMenuItem {
    static LAST_CONNECTION_KEY = 'nm-connections-last-modem';

    _init(device) {
        super._init(device);

        const capabilities = device.current_capabilities;
        if (device.udi.indexOf('/org/freedesktop/ModemManager1/Modem') === 0)
            this._mobileDevice = new ModemManager.BroadbandModem(device.udi, capabilities);
        else if (capabilities & NM.DeviceModemCapabilities.GSM_UMTS)
            this._mobileDevice = new ModemManager.ModemGsm(device.udi);
        else if (capabilities & NM.DeviceModemCapabilities.CDMA_EVDO)
            this._mobileDevice = new ModemManager.ModemCdma(device.udi);
        else if (capabilities & NM.DeviceModemCapabilities.LTE)
            this._mobileDevice = new ModemManager.ModemGsm(device.udi);

        this._mobileDevice?.connectObject(
            'notify::operator-name', () => this.notify('label'),
            'notify::signal-quality', () => this.notify('icon-name'),
            this);
    }

    get wwanPanelSupported() {
        // Currently, wwan panel doesn't support CDMA_EVDO modems
        const supportedCaps =
            NM.DeviceModemCapabilities.GSM_UMTS |
            NM.DeviceModemCapabilities.LTE;
        return this._device.current_capabilities & supportedCaps;
    }

    _autoConnect() {
        if (this._useWwanPanel())
            launchSettingsPanel('wwan', 'show-device', this._device.udi);
        else
            launchSettingsPanel('network', 'connect-3g', this._device.get_path());
    }

    get label() {
        return this._mobileDevice?.operator_name || this._deviceName;
    }

    get iconName() {
        if (!this._activeConnection)
            return 'network-cellular-disabled-symbolic';

        switch (this._activeConnection?.state) {
        case NM.ActiveConnectionState.ACTIVATING:
            return 'network-cellular-acquiring-symbolic';
        case NM.ActiveConnectionState.ACTIVATED:
            const {signalQuality} = this._mobileDevice;
            let strength;
            if (signalQuality < 20)
                strength = 'none';
            else if (signalQuality < 40)
                strength = 'weak';
            else if (signalQuality < 50)
                strength = 'ok';
            else if (signalQuality < 80)
                strength = 'good';
            else
                strength = 'excellent';
            return `network-cellular-signal-${strength}-symbolic`;
        default:
            return 'network-cellular-signal-none-symbolic';
        }
    }
});

const WirelessDeviceSection = GObject.registerClass(
class WirelessDeviceSection extends NMMenuItem {
    static LAST_CONNECTION_KEY = 'nm-connections-last-wireless';

    constructor(device) {
        super();

        this._device = device;
        this._device.connectObject(
            'access-point-added', (d, ap) => this._addAccessPoint(ap),
            'access-point-removed', (d, ap) => this._removeAccessPoint(ap),
            'notify::active-access-point', () => this._syncActiveAp(),
            this);

        for (const ap of this._device.get_access_points())
            this._addAccessPoint(ap);

        this._syncActiveAp();
    }

    get device() {
        return this._device;
    }
});

const VpnMenuItem = GObject.registerClass(
class VpnMenuItem extends NMMenuItem {
    _init(conn) {
        super._init();

        this._connection = conn;

        const label = new St.Label({
            x_expand: true,
            y_expand: true,
            y_align: Clutter.ActorAlign.CENTER,
        });
        this.add_child(label);

        const swtch = new PopupMenu.Switch(this.isActive);
        this.add_child(swtch);

        this.accessible_role = Atk.Role.CHECK_MENU_ITEM;
        swtch.connect('notify::state', () => {
            if (swtch.state)
                this.add_accessible_state(Atk.StateType.CHECKED);
            else
                this.remove_accessible_state(Atk.StateType.CHECKED);
        });

        this.bind_property('label',
            label, 'text',
            GObject.BindingFlags.SYNC_CREATE);
        this.bind_property('is-active',
            swtch, 'state',
            GObject.BindingFlags.SYNC_CREATE);
    }

    get label() {
        return this._connection.get_id();
    }

    get iconName() {
        switch (this.state) {
        case NM.ActiveConnectionState.ACTIVATING:
            return 'network-vpn-acquiring-symbolic';
        case NM.ActiveConnectionState.ACTIVATED:
            return 'network-vpn-symbolic';
        default:
            return 'network-vpn-disabled-symbolic';
        }
    }

    activate() {
        super.activate();

        const { client } = this._connection;

        if (!this._activeConnection)
            client.activate_connection_async(this._connection, null, null, null, null);
        else
            client.deactivate_connection_async(this._activeConnection, null, null);
    }

    setActiveConnection(activeConnection) {
        this._setActiveConnection(activeConnection);
    }

    _activeConnectionStateChanged() {
        super._activeConnectionStateChanged();

        const { state, connection } = this._activeConnection ?? {};
        if (state === NM.ActiveConnectionState.ACTIVATED) {
            mySettings.set_string('nm-connections-last-vpn',
                connection.get_uuid());
        }
    }
});

const NMToggle = GObject.registerClass(
class NMToggle extends QuickMenuToggle {
    _init(fallbackLabel, fallbackIcon) {
        super._init({
            label: fallbackLabel,
            iconName: fallbackIcon,
            visible: false,
        });

        this._items = new Map();

        this._fallbackLabel = fallbackLabel;
        this._fallbackIcon = fallbackIcon;

        this._itemBinding = new GObject.BindingGroup();
        this._itemBinding.bind('label',
            this, 'label', GObject.BindingFlags.DEFAULT);
        this._itemBinding.bind('icon-name',
            this, 'icon-name', GObject.BindingFlags.DEFAULT);

        this._primaryItem = null;
        this._lastConnectedItem = null;

        this.connect('clicked', () => this.activate());
    }

    setClient(client) {
        this._client?.disconnectObject(this);
        this._client = client;
        this._client?.connectObject(
            'notify::nm-running', () => this._sync(),
            'notify::networking-enabled', () => this._sync(),
            this);

        if (this._client)
            this._loadInitialItems();

        const key = this.constructor['LAST_CONNECTION_KEY'];
        mySettings.connectObject(`changed::${key}`,
            () => this._updateLastConnectedItem(), this);
        this._updateLastConnectedItem();

        this._sync();
    }

    activate() {
        const items = [...this._items.values()];
        const activeItems = items.filter(i => i.isActive);

        if (activeItems.length > 0)
            activeItems.forEach(i => i.activate());
        else
            this._itemBinding.source?.activate();
    }

    _loadInitialItems() {
        throw new GObject.NotImplementedError();
    }

    _getPrimaryItem() {
        return null;
    }

    _updatePrimaryItem() {
        this._primaryItem = this._getPrimaryItem();
        this._syncItemBinding();
    }

    _syncItemBinding() {
        this._itemBinding.source = this._primaryItem || this._lastConnectedItem;

        if (!this._itemBinding.source) {
            this.set({
                label: this._fallbackLabel,
                iconName: this._fallbackIcon,
            });
        }
    }

    _getLastConnectedItem() {
        return null;
    }


    _updateLastConnectedItem() {
        const lastConnected = this._getLastConnectedItem();
        if (this._lastConnectedItem === lastConnected)
            return;

        this._lastConnectedItem = lastConnected;

        if (!this._itemBinding.source)
            this._syncItemBinding();
    }

    _updateChecked() {
        const items = [...this._items.values()];
        this.checked = items.some(i => i.isActive);
    }

    _shouldBeVisible() {
        return (this._client?.nm_running ?? false) && this._items.size > 0;
    }

    _sync() {
        this._updatePrimaryItem();

        this.visible = this._shouldBeVisible();
        this.reactive = this._client?.networking_enabled ?? false;
        this._updateChecked();
    }
});

const NMDeviceToggle = GObject.registerClass(
class NMDeviceToggle extends NMToggle {
    _init(...params) {
        super._init(...params);

        this._deviceType = null;
        this._nmDevices = new Set();

        this._devicesSection = new PopupMenu.PopupMenuSection();
        this.menu.addMenuItem(this._devicesSection);
    }

    setClient(client) {
        super.setClient(client);

        this._client?.connectObject(
            'device-added', (c, dev) => {
                this._addDevice(dev);
                this._syncDeviceNames();
            },
            'device-removed', (c, dev) => {
                this._removeDevice(dev);
                this._syncDeviceNames();
            },
            this);
    }

    _loadInitialItems() {
        const devices = this._client.get_devices() || [];
        for (const dev of devices)
            this._addDevice(dev);
        this._syncDeviceNames();
    }

    _shouldShowDevice(device) {
        switch (device.state) {
        case NM.DeviceState.DISCONNECTED:
        case NM.DeviceState.ACTIVATED:
        case NM.DeviceState.DEACTIVATING:
        case NM.DeviceState.PREPARE:
        case NM.DeviceState.CONFIG:
        case NM.DeviceState.IP_CONFIG:
        case NM.DeviceState.IP_CHECK:
        case NM.DeviceState.SECONDARIES:
        case NM.DeviceState.NEED_AUTH:
        case NM.DeviceState.FAILED:
            return true;
        case NM.DeviceState.UNMANAGED:
        case NM.DeviceState.UNAVAILABLE:
        default:
            return false;
        }
    }

    _getPrimaryItem() {
        const items = [...this._items.values()];
        if (items.length === 1)
            return items[0];

        const activeItems = items.filter(i => i.isActive);
        if (activeItems.length === 1)
            return activeItems[0];

        return null;
    }

    _getLastConnectedItem() {
        const items = [...this._items.values()];
        return items.find(item => item.lastConnection !== null) ?? null;
    }

    _syncDeviceNames() {
        const names = NM.Device.disambiguate_names([...this._items.keys()]);
        [...this._items.values()].forEach(
            (item, i) => item.setDeviceName(names[i]));
    }

    _syncDeviceItem(device) {
        if (this._shouldShowDevice(device))
            this._ensureDeviceItem(device);
        else
            this._removeDeviceItem(device);
    }

    _createDeviceMenuItem(device) {
        return new DeviceMenuItem(device);
    }

    _itemDestroyed(item) {
        if (this._primaryItem === item)
            this._primaryItem = null;
        if (this._lastConnectedItem === item)
            this._lastConnectedItem = null;
        if (this._itemBinding.source === item)
            this._itemBinding.source = null;
    }

    _ensureDeviceItem(device) {
        if (this._items.has(device))
            return;

        const item = this._createDeviceMenuItem(device);
        item.connectObject(
            'notify::is-active', () => this._sync(),
            'destroy', () => this._itemDestroyed(item),
            this);

        this._items.set(device, item);
        this._devicesSection.addMenuItem(item);

        this._sync();
    }

    _removeDeviceItem(device) {
        this._items.get(device)?.destroy();
        if (this._items.delete(device))
            this._sync();
    }

    _addDevice(device) {
        if (this._nmDevices.has(device))
            return;

        if (device.get_device_type() !== this._deviceType)
            return;

        device.connectObject(
            'notify::interface', () => this._syncDeviceNames(),
            'notify::state', () => this._syncDeviceItem(device),
            this);

        this._nmDevices.add(device);
        this._syncDeviceItem(device);
    }

    _removeDevice(device) {
        if (!this._nmDevices.delete(device))
            return;

        device.disconnectObject(this);
        this._removeDeviceItem(device);
    }

    _sync() {
        super._sync();

        const disableSubmenu = this._items.size === 1;
        for (const item of this._items.values())
            item.disableSubmenu = disableSubmenu;
    }
});

const WirelessToggle = GObject.registerClass(
class WirelessToggle extends NMDeviceToggle {
    static LAST_CONNECTION_KEY = 'nm-connections-last-wireless';

    _init() {
        super._init(_('Wi–Fi'), 'network-wireless-disabled-symbolic');

        this._deviceType = NM.DeviceType.WIFI;

        this._scanningSpinner = new Spinner(16);

        this.menu.connect('open-state-changed', (m, isOpen) => {
            if (isOpen)
                this._startScanning();
            else
                this._stopScanning();
        });

        this.menu.setHeader('network-wireless-symbolic', _('Wi–Fi'));
        this.menu.addHeaderSuffix(this._scanningSpinner);
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this.menu.addSettingsAction(_('All Networks'),
            'gnome-wifi-panel.desktop');
    }

    setClient(client) {
        super.setClient(client);

        client?.bind_property('wireless-enabled',
            this, 'checked',
            GObject.BindingFlags.SYNC_CREATE);
        client?.connectObject(
            'notify::wireless-hardware-enabled', () => this._sync(),
            this);
    }

    _getPrimaryItem() {
        const item = [...this._items.values()].find(i => i.isHotspot);
        if (item)
            return item;

        return super._getPrimaryItem();
    }

    activate() {
        if (this._primaryItem?.isHotspot) {
            this._primaryItem.activate();
        } else {
            const { wirelessEnabled } = this._client;
            this._client.wirelessEnabled = !wirelessEnabled;
        }
    }

    async _scanDevice(device) {
        const {lastScan} = device;
        await device.request_scan_async(null);

        // Wait for the lastScan property to update, which
        // indicates the end of the scan
        return new Promise(resolve => {
            GLib.timeout_add(GLib.PRIORITY_DEFAULT, 1500, () => {
                if (device.lastScan === lastScan)
                    return GLib.SOURCE_CONTINUE;

                resolve();
                return GLib.SOURCE_REMOVE;
            });
        });
    }

    async _scanDevices() {
        this._scanningSpinner.play();

        const devices = [...this._items.keys()];
        await Promise.all(
            devices.map(d => this._scanDevice(d)));

        this._scanningSpinner.stop();
    }

    _startScanning() {
        this._scanTimeoutId = GLib.timeout_add_seconds(
            GLib.PRIORITY_DEFAULT, WIFI_SCAN_FREQUENCY, () => {
                this._scanDevices();
                return GLib.SOURCE_CONTINUE;
            });
        this._scanDevices();
    }

    _stopScanning() {
        GLib.source_remove(this._scanTimeoutId);
        delete this._scanTimeoutId;
    }

    _shouldShowDevice(device) {
        return device.state !== NM.DeviceState.UNMANAGED;
    }

    _shouldBeVisible() {
        return super._shouldBeVisible() && this._client.wireless_hardware_enabled;
    }

    _updateChecked() {
        // handled via property binding
    }

    _createDeviceMenuItem(device) {
        return new WirelessDeviceMenuItem(device);
    }
});

const WiredToggle = GObject.registerClass(
class WiredToggle extends NMDeviceToggle {
    static LAST_CONNECTION_KEY = 'nm-connections-last-wired';

    _init() {
        super._init(_('Wired'), 'network-wired-disconnected-symbolic');

        this._deviceType = NM.DeviceType.ETHERNET;

        this.menu.setHeader('network-wired-symbolic', _('Wired'));
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this.menu.addSettingsAction(_('Wired Settings'),
            'gnome-network-panel.desktop');
    }

    _createDeviceMenuItem(device) {
        return new WiredDeviceMenuItem(device);
    }
});

const BtToggle = GObject.registerClass(
class BtToggle extends NMDeviceToggle {
    static LAST_CONNECTION_KEY = 'nm-connections-last-bluetooth';

    _init() {
        super._init(_('Bluetooth'), 'network-cellular-disabled-symbolic');

        this._deviceType = NM.DeviceType.BT;

        this.menu.setHeader('network-cellular-symbolic', _('Bluetooth'));
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this.menu.addSettingsAction(_('Bluetooth Settings'),
            'gnome-network-panel.desktop');
    }

    _createDeviceMenuItem(device) {
        const item = new BtDeviceMenuItem(device);
        device.connectObject(
            'notify::available-connections', () => this._updateLastConnectedItem(),
            item);
        return item;
    }
});

const ModemToggle = GObject.registerClass(
class ModemToggle extends NMDeviceToggle {
    static LAST_CONNECTION_KEY = 'nm-connections-last-modem';

    _init() {
        super._init(_('Mobile Broadband'), 'network-cellular-disabled-symbolic');

        this._deviceType = NM.DeviceType.Modem;

        this.menu.setHeader('network-cellular-symbolic', _('Mobile Broadband'));
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this._wwanSettings =
            this.menu.addSettingsAction(_('Mobile Broadband Settings'), 'gnome-wwan-panel.destkop');
        this._legacySettings =
            this.menu.addSettingsAction(_('Mobile Broadband Settings'), 'gnome-network-panel.destkop');
    }

    _createDeviceMenuItem(device) {
        return new ModemDeviceMenuItem(device);
    }

    _sync() {
        super._sync();

        const useWwanPanel =
            [...this._items.values()].some(i => i.wwanPanelSupported);
        this._wwanSettings.visible = useWwanPanel;
        this._legacySettings.visible = !useWwanPanel;
    }
});

const VpnToggle = GObject.registerClass(
class VpnToggle extends NMToggle {
    static LAST_CONNECTION_KEY = 'nm-connections-last-vpn';

    _init() {
        super._init(_('VPN'), 'network-vpn-disabled-symbolic');

        this._activeConnections = [];

        this.menu.setHeader('network-vpn-symbolic', _('VPN'));

        this._connectionsSection = new PopupMenu.PopupMenuSection();
        this.menu.addMenuItem(this._connectionsSection);

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this.menu.addSettingsAction(_('VPN Settings'),
            'gnome-network-panel.desktop');
    }

    setClient(client) {
        super.setClient(client);

        this._client?.connectObject(
            'connection-added', (c, conn) => this._addConnection(conn),
            'connection-removed', (c, conn) => this._removeConnection(conn),
            'notify::active-connections', () => this._syncActiveConnections(),
            this);
    }

    _loadInitialItems() {
        const connections = this._client?.get_connections() || [];
        for (const conn of connections)
            this._addConnection(conn);

        this._syncActiveConnections();
    }

    _getPrimaryItem() {
        const items = [...this._items.values()];
        if (items.length === 1)
            return items[0];

        if (this._activeConnections.length === 1)
            return this._items.get(this._activeConnections[0].connection);

        return null;
    }

    _getLastConnectedItem() {
        const uuid = mySettings.get_string(this.constructor['LAST_CONNECTION_KEY']);
        const conn = this._client?.get_connection_by_uuid(uuid);
        return this._items.get(conn) ?? null;
    }

    _syncActiveConnections() {
        const connections = this._client.get_active_connections() || [];
        this._activeConnections = connections.filter(
            c => this._shouldHandleConnection(c.connection));

        for (const item of this._items.values())
            item.setActiveConnection(null);

        for (const a of this._activeConnections)
            this._items.get(a.connection)?.setActiveConnection(a);

        this._sync();
    }

    _shouldHandleConnection(connection) {
        const setting = connection.get_setting_connection();
        if (!setting)
            return false;

        // Ignore slave connection
        if (setting.get_master())
            return false;

        const handledTypes = [
            NM.SETTING_VPN_SETTING_NAME,
            NM.SETTING_WIREGUARD_SETTING_NAME,
        ];
        return handledTypes.includes(setting.type);
    }

    _addConnection(connection) {
        if (this._items.has(connection))
            return;

        if (!this._shouldHandleConnection(connection))
            return;

        const item = new VpnMenuItem(connection);
        this._connectionsSection.addMenuItem(item);

        this._items.set(connection, item);
        this._sync();
    }

    _removeConnection(connection) {
        this._items.get(connection)?.destroy();
        if (this._items.delete(connection))
            this._sync();
    }
});

var Indicator = class {
    constructor() {
        globalThis.mySettings = ExtensionUtils.getSettings();

        this.quickSettingsItems = [];

        this._wiredToggle = new WiredToggle();
        this._wirelessToggle = new WirelessToggle();
        this._wwanToggle = new ModemToggle();
        this._btToggle = new BtToggle();
        this._vpnToggle = new VpnToggle();

        this.quickSettingsItems.push(this._wiredToggle);
        this.quickSettingsItems.push(this._wirelessToggle);
        this.quickSettingsItems.push(this._wwanToggle);
        this.quickSettingsItems.push(this._btToggle);
        this.quickSettingsItems.push(this._vpnToggle);

        this._getClient().catch(logError);
    }

    async _getClient() {
        this._client = await NM.Client.new_async(null);

        this._wiredToggle.setClient(this._client);
        this._wirelessToggle.setClient(this._client);
        this._wwanToggle.setClient(this._client);
        this._btToggle.setClient(this._client);
        this._vpnToggle.setClient(this._client);
    }
};
