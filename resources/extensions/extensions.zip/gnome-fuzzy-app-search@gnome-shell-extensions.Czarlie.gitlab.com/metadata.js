export const metadata = {
    uuid: "gnome-fuzzy-app-search@gnome-shell-extensions.Czarlie.gitlab.com",
    version: "5.0.15",
};
export default metadata;
